from dataclasses import dataclass
from typing import Optional

@dataclass
class Jugador:
    id: Optional[int]
    nombre: str
    grado: str

@dataclass
class Usuario:
    id: Optional[int]
    username: str
    password: str
    rol: str

@dataclass
class Gol:
    id: Optional[int]
    jugador_id: int
    fecha: str
    descripcion: str
