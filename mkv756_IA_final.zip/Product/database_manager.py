import sqlite3
import os

class DatabaseManager:
    def __init__(self, db_name="goles.db"):
        self.db_name = db_name
        self._init_db()

    def _get_connection(self):
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _init_db(self):
        conn = self._get_connection()
        cursor = conn.cursor()
        
        # Tabla Usuarios
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            rol TEXT CHECK(rol IN ('admin', 'consultor')) NOT NULL
        )
        """)
        
        # Tabla Jugadores
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS jugadores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            grado TEXT NOT NULL
        )
        """)
        
        # Tabla Temporadas
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS temporadas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT UNIQUE NOT NULL,
            activa BOOLEAN NOT NULL DEFAULT 0
        )
        """)
        
        # Asegurar temporada inicial
        cursor.execute("SELECT count(*) FROM temporadas")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO temporadas (nombre, activa) VALUES ('Temporada Principal', 1)")

        # Tabla Goles
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS goles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            jugador_id INTEGER NOT NULL,
            fecha TEXT NOT NULL,
            descripcion TEXT,
            temporada_id INTEGER DEFAULT 1,
            FOREIGN KEY (jugador_id) REFERENCES jugadores(id) ON DELETE CASCADE,
            FOREIGN KEY (temporada_id) REFERENCES temporadas(id) ON DELETE CASCADE
        )
        """)
        
        # Migración: add temporada_id to goles si venimos de version anterior
        cursor.execute("PRAGMA table_info(goles)")
        columns = [col[1] for col in cursor.fetchall()]
        if 'temporada_id' not in columns:
            cursor.execute("ALTER TABLE goles ADD COLUMN temporada_id INTEGER DEFAULT 1")
        
        # Insertar usuario admin por defecto si no existe
        cursor.execute("SELECT id FROM usuarios WHERE username = 'admin'")
        if not cursor.fetchone():
            cursor.execute("INSERT INTO usuarios (username, password, rol) VALUES (?, ?, ?)", 
                           ("admin", "1234", "admin"))
            cursor.execute("INSERT INTO usuarios (username, password, rol) VALUES (?, ?, ?)", 
                           ("invitado", "invitado", "consultor"))
        
        conn.commit()
        conn.close()

    # --- CRUD Jugadores ---
    def jugador_existe(self, nombre, grado):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM jugadores WHERE nombre = ? AND grado = ?", (nombre, grado))
        existe = cursor.fetchone() is not None
        conn.close()
        return existe

    def agregar_jugador(self, nombre, grado):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO jugadores (nombre, grado) VALUES (?, ?)", (nombre, grado))
        conn.commit()
        conn.close()

    def obtener_jugadores(self):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM jugadores ORDER BY nombre ASC")
        rows = cursor.fetchall()
        conn.close()
        return rows

    def eliminar_jugador(self, jugador_id):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM jugadores WHERE id = ?", (jugador_id,))
        conn.commit()
        conn.close()

    # --- Gestión Temporadas ---
    def obtener_temporadas(self):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM temporadas ORDER BY id DESC")
        rows = cursor.fetchall()
        conn.close()
        return rows
        
    def obtener_temporada_activa(self):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM temporadas WHERE activa = 1 LIMIT 1")
        row = cursor.fetchone()
        conn.close()
        return row
        
    def obtener_temporada_por_nombre(self, nombre):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM temporadas WHERE nombre = ?", (nombre,))
        row = cursor.fetchone()
        conn.close()
        return row

    def crear_temporada(self, nombre):
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO temporadas (nombre, activa) VALUES (?, 0)", (nombre,))
            temporada_id = cursor.lastrowid
            cursor.execute("UPDATE temporadas SET activa = 0")
            cursor.execute("UPDATE temporadas SET activa = 1 WHERE id = ?", (temporada_id,))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            conn.rollback()
            return False
        finally:
            conn.close()

    def activar_temporada(self, temporada_id):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE temporadas SET activa = 0")
        cursor.execute("UPDATE temporadas SET activa = 1 WHERE id = ?", (temporada_id,))
        conn.commit()
        conn.close()

    def eliminar_temporada(self, temporada_id):
        conn = self._get_connection()
        cursor = conn.cursor()
        # Verificar si es la única temporada activa
        cursor.execute("SELECT activa FROM temporadas WHERE id = ?", (temporada_id,))
        activa = cursor.fetchone()['activa']
        
        cursor.execute("DELETE FROM temporadas WHERE id = ?", (temporada_id,))
        
        # Si eliminamos la activa, activar la más reciente
        if activa:
            cursor.execute("SELECT id FROM temporadas ORDER BY id DESC LIMIT 1")
            row = cursor.fetchone()
            if row:
                cursor.execute("UPDATE temporadas SET activa = 1 WHERE id = ?", (row['id'],))
                
        conn.commit()
        conn.close()

    # --- Gestión de Goles ---
    def registrar_gol(self, jugador_id, fecha, descripcion, temporada_id=None):
        if temporada_id is None:
            temporada_activa = self.obtener_temporada_activa()
            temporada_id = temporada_activa['id'] if temporada_activa else 1
            
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO goles (jugador_id, fecha, descripcion, temporada_id) VALUES (?, ?, ?, ?)", 
                       (jugador_id, fecha, descripcion, temporada_id))
        conn.commit()
        conn.close()

    def obtener_ranking(self, temporada_id=None):
        conn = self._get_connection()
        cursor = conn.cursor()
        
        query_temporada = ""
        params = []
        if temporada_id:
            query_temporada = "AND g.temporada_id = ?"
            params.append(temporada_id)
            
        cursor.execute(f"""
            SELECT j.nombre, j.grado, COUNT(g.id) as total_goles
            FROM jugadores j
            JOIN goles g ON j.id = g.jugador_id {query_temporada}
            GROUP BY j.id
            ORDER BY total_goles DESC, j.nombre ASC
        """, params)
        rows = cursor.fetchall()
        conn.close()
        return rows

    def obtener_estadisticas(self, temporada_id=None):
        conn = self._get_connection()
        cursor = conn.cursor()
        
        params = []
        query_filtro = ""
        if temporada_id:
            query_filtro = "WHERE temporada_id = ?"
            params.append(temporada_id)
            
        cursor.execute(f"SELECT COUNT(*) FROM goles {query_filtro}", params)
        total_goles = cursor.fetchone()[0]
        
        query_filtro_max = ""
        if temporada_id:
            query_filtro_max = "AND g.temporada_id = ?"
            
        cursor.execute(f"""
            SELECT j.nombre, COUNT(g.id) as max_goles
            FROM jugadores j
            JOIN goles g ON j.id = g.jugador_id {query_filtro_max}
            GROUP BY j.id
            ORDER BY max_goles DESC
            LIMIT 1
        """, params)
        pichichi = cursor.fetchone()
        conn.close()
        return {"total_goles": total_goles, "pichichi": pichichi[0] if pichichi else "N/A"}

    def validar_login(self, username, password):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT rol FROM usuarios WHERE username = ? AND password = ?", (username, password))
        row = cursor.fetchone()
        conn.close()
        return row[0] if row else None
