# Guion Final mkv756 (Versión Funcional Neutra)
**Instrucción:** Esta versión evita tecnicismos y suena más natural. Explica lo que sucede con los datos sin usar palabras complicadas.

---

## 1. El Problema y la Solución (0:00 - 0:30)
**Muestra la portada HTML.**  
"Este es el sistema Linces Iberia. Lo diseñé para automatizar el ranking de goleadores del Departamento de Deporte. El objetivo es eliminar los conteos manuales, para que todo el proceso sea automático y los resultados sean inmediatos."

## 2. Acceso y Seguridad de Datos (0:30 - 1:15)
**Cambia al programa y entra como Invitado.**  
"Como podemos ver aquí, el sistema tiene un login donde podemos entrar como administrador o invitado. Si entramos como 'invitado', las opciones de editar y borrar ni siquiera aparecen en el menú lateral. Esto protege la integridad de los resultados, asegurando que nadie sin autorización pueda modificar los registros de los alumnos."

## 3. Gestión y Registro de Alumnos (1:15 - 2:30)
**Entra como Admin y ve a 'Gestionar Jugadores'.**  
"Aquí manejamos a los estudiantes con su nombre y grado. Por ejemplo, al registrar dos jugadores con el mismo nombre y el mismo grupo, el sistema nos da un aviso porque detecta un duplicado. Pero si el grado es diferente, ahí sí permite guardarlo, porque entiende que son alumnos distintos."

## 4. Funcionamiento de los Goles y Redirección (2:30 - 3:45)
**Ve a 'Registrar Goles'.**  
"Para registrar los goles, vemos la lista completa con el nombre y la categoría de cada lince. El registro es directo: seleccionas al estudiante, pones los goles y el sistema los suma instantáneamente al total. Algo muy práctico es que, al guardar, el sistema nos manda automáticamente al Ranking Pichichi para ver la tabla actualizada al momento."

## 5. Ranking Pichichi Automático (3:45 - 4:45)
**Ve al Ranking Pichichi.**  
"El ranking se ordena solo de mayor a menor basándose en los datos registrados. También resaltamos los tres primeros puestos para que los alumnos se sientan motivados al ver sus posiciones directamente en la tabla."

## 6. Estadísticas y Resumen de Temporada (4:45 - 5:30)
**Ve a 'Estadísticas'.**  
"En esta parte vemos el resumen global de la temporada actual. Aquí el sistema nos da el **Total de Goles de toda la liga** y el **Máximo Goleador**. Aunque parezca simple, este apartado es fundamental para que el Departamento de Deporte pueda comparar el nivel de competitividad y la participación entre diferentes años de forma analítica."

## 7. Temporadas y Persistencia (5:30 - 6:45)
**Ve a 'Gestión Temporadas'.**  
"Usamos las temporadas para no mezclar los datos de años distintos. Una temporada sale como activa y la otra como expirada, pero todavía se puede consultar la anterior.  

Algo muy importante sobre la integridad de los datos: no borramos a los alumnos al cambiar de año ni cuando se gradúan. El ranking está vinculado a la temporada seleccionada; si un alumno ya no juega en la liga actual, el sistema lo detecta y no aparece en la lista de este año, pero todos sus récords de temporadas pasadas se quedan guardados de forma segura."

## 8. Cierre
**Vuelve al inicio.**  
"En resumen, es una herramienta rápida y segura para la liga escolar. ¡Muchas gracias por ver!"
